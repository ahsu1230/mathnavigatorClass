console.log("My Javascript works");

function init() {
  console.log("jQuery ready!");

  // Setup on-click handler
  $("button").on("click", handleClick);
}

function handleClick() {
  // Checkpoints 1a & 1b
  // 1) With jQuery, retrieve the values for flavor, ice-amount, sugar-amount
  //    Hint: use $(...).val()
  // 2) Create a url. It should look something like this:
  //    html/receipt.html?flavor=___&ice=____&sugar=___
  //    console.log your url to see if it works as expected!
  // 3) Use "window.location = ..." to move to the next webpage
  // Your code goes here! Please delete these comments when you finish!
}


$(document).ready(init);