console.log("My Javascript works");

$(document).ready(function() {
  console.log("jQuery ready!");

  $("...").on("click", function(event) {

    // Your code goes here!
    
  });
});